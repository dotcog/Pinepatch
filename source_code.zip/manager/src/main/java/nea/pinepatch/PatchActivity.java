package nea.pinepatch;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.util.zip.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import android.content.res.*;
import android.net.*;
import com.apk.axml.*;

public class PatchActivity extends Activity
implements Runnable
{

	static Thread patchingThread;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		if (patchingThread == null)
		{
			setTitle(R.string.patching_apk);
			setContentView(new ProgressBar(this));
			patchingThread = new Thread(this);
			patchingThread.start();
		}
	}

	@Override
	public void run()
	{
		String errorString = null;
		try
		{
			InputStream in = null;
			Uri uri = getIntent().getData();
			switch (uri.getScheme())
			{
				case "file":
					in = new URL(getIntent().getData().toString()).openStream();
					break;
				case "content":
					in = getContentResolver().openInputStream(uri);
					break;
			}
			Utils.deleteFile(Utils.PATCH_PATH);
			OutputStream out = new FileOutputStream(Utils.newFile(Utils.PATCH_PATH + "rawapk"));
			Utils.transfer(in, out);
			in.close();
			out.flush();
			out.close();
			try
			{
				String signature = ApkSignatureHelper.getApkSignInfo(Utils.PATCH_PATH + "rawapk");
				FileWriter signOut = new FileWriter(Utils.PATCH_PATH + "rawsign");
				signOut.write(signature);
				signOut.flush();
				signOut.close();
			}
			catch (Throwable e) {}
			in = new FileInputStream(Utils.PATCH_PATH + "rawapk");
			OutputStream outPatchedApk = new FileOutputStream(Utils.newFile(Environment.getExternalStorageDirectory() + "/pinepatch/patched.apk"));
			ZipInputStream zin = new ZipInputStream(in);
			ZipOutputStream zout = new ZipOutputStream(outPatchedApk);
			ZipEntry entry = null;
			String packageName = null;
			AssetManager assets = getAssets();
			while ((entry = zin.getNextEntry()) != null)
			{
				String path = entry.getName();
				if (path.startsWith("META-INF/"))
				{} else if (path.equals("AndroidManifest.xml"))
				{
					ZipEntry newEntry = new ZipEntry(path);
					Utils.setZipEntry(entry, newEntry);
					zout.putNextEntry(newEntry);
					String xmlString = new aXMLDecoder().decode(zin);
					Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(xmlString.getBytes("utf-8")));
					Element manifestEle = doc.getDocumentElement();
					packageName = manifestEle.getAttribute("package");
					try
					{
						Element sdkElement = (Element) manifestEle.getElementsByTagName("uses-sdk").item(0);
						int targetSdkVersion = Integer.parseInt(sdkElement.getAttribute("android:targetSdkVersion"));
						if (targetSdkVersion < 28)
						{
							targetSdkVersion = 28;
						}
						if (targetSdkVersion >= 31)
						{
							Element queriesElement = doc.createElement("queries");
							Element packageElement = doc.createElement("package");
							packageElement.setAttribute("android:name", "nea.pinepatch");
							queriesElement.appendChild(packageElement);
							manifestEle.appendChild(queriesElement);
						}
						sdkElement.setAttribute("android:targetSdkVersion", String.valueOf(targetSdkVersion));
					}
					catch (Exception e) {}
					Element applicationEle = (Element) manifestEle.getElementsByTagName("application").item(0);
					String rawAppComponentFactory = null, appComponentFactoryAttrName = "android:appComponentFactory";
					if (applicationEle.hasAttribute(appComponentFactoryAttrName))
					{
						rawAppComponentFactory = applicationEle.getAttribute(appComponentFactoryAttrName);
					}
					applicationEle.setAttribute(appComponentFactoryAttrName, "nea.pinepatch.PineLoader");
					if (rawAppComponentFactory != null)
					{
						FileWriter rawAppcfOut = new FileWriter(Utils.newFile(Utils.PATCH_PATH + "rawappcf"));
						rawAppcfOut.write(rawAppComponentFactory);
						rawAppcfOut.flush();
						rawAppcfOut.close();
					}
					TransformerFactory tf = TransformerFactory.newInstance();
					Transformer t = tf.newTransformer();
					t.setOutputProperty("encoding", "utf-8");
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					t.transform(new DOMSource(doc), new StreamResult(bos));
					xmlString = bos.toString("utf-8");
					ByteArrayInputStream manifestIn = new ByteArrayInputStream(new aXMLEncoder().encodeString(this, xmlString));
					Utils.transfer(manifestIn, zout);
					zout.closeEntry();
				} else
				{
					if (path.startsWith("classes") && path.endsWith(".dex") && ! path.contains("/"))
					{
						String numString = path.substring(7, path.length() - 4);
						if (numString.length() == 0)
						{
							ZipEntry newEntry = new ZipEntry(path);
							Utils.setZipEntry(entry, newEntry);
							zout.putNextEntry(newEntry);
							InputStream metaloaderIn = assets.open("loader.dex");
							Utils.transfer(metaloaderIn, zout);
							metaloaderIn.close();
							zout.closeEntry();
						}
						path = null;
					}
					if (path != null)
					{
						ZipEntry newEntry = new ZipEntry(path);
						Utils.setZipEntry(entry, newEntry);
						zout.putNextEntry(newEntry);
						Utils.transfer(zin, zout);
						zout.closeEntry();
					}
				}
				zin.closeEntry();
			}
			in.close();
			zin.close();
			zout.flush();
			zout.close();
			outPatchedApk.flush();
			outPatchedApk.close();
			FileWriter pathOut = new FileWriter(Utils.newFile(Utils.PATCH_PATH + "apkpath"));
			pathOut.write("/cache/pipatch/base.apk");
			pathOut.flush();
			pathOut.close();
			pathOut = new FileWriter(Utils.newFile(Utils.PATCH_PATH + "sopath"));
			pathOut.write("/cache/pipatch/pine.so");
			pathOut.flush();
			pathOut.close();
			File appFolder = Utils.newFolder(Utils.APP_PATH + packageName.toString());
			File modulesFile = Utils.newFile(appFolder.getPath() + "/modules");
			if (modulesFile.exists())
			{
				modulesFile.renameTo(Utils.newFile(Utils.PATCH_PATH + "modules"));
			}
			Utils.deleteFile(appFolder);
			Utils.newFolder(Utils.PATCH_PATH).renameTo(appFolder);
		}
		catch (Throwable e)
		{
			StringWriter out = new StringWriter();
			e.printStackTrace(new PrintWriter(out));
			out.flush();
			try
			{
				out.close();
			}
			catch (Exception e2)
			{}
			errorString = out.toString();
		}
		final String finalErrorString = errorString;
		runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					if (finalErrorString == null)
					{
						setTitle(R.string.finish);
						setContentView(R.layout.activity_patch);
					} else
					{
						Toast.makeText(PatchActivity.this, finalErrorString, Toast.LENGTH_SHORT).show();
						finishAndRemoveTask();
					}
				}
			});
	}
}
