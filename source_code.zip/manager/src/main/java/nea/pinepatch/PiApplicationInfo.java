package nea.pinepatch;
import android.graphics.drawable.*;
import android.content.pm.*;
import java.io.*;
import android.content.pm.PackageManager.*;
import android.content.*;

public class PiApplicationInfo
{
	public String packageName, label;
	public Drawable icon;
	boolean isInstalled;

	public PiApplicationInfo(Context context, String packageName)
	{
		this.packageName = packageName;
		try
		{
			PackageManager manager = context.getPackageManager();
			try
			{
				label = manager.getApplicationLabel(manager.getApplicationInfo(packageName, 0)).toString();
				icon = manager.getApplicationIcon(packageName);
				isInstalled = true;
			}
			catch (PackageManager.NameNotFoundException e)
			{
				isInstalled = false;
			}
		}
		catch (Exception e)
		{
			isInstalled = false;
		}
	}

	public void uninstall ()
	{
		Utils.deleteFile(Utils.APP_PATH + packageName);
	}
}
