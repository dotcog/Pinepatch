package nea.pinepatch;
import android.os.*;
import java.io.*;
import android.content.*;
import java.util.zip.*;
import java.util.*;
import android.content.pm.*;

public class Utils
{
	public static String PI_PATH;
	public static String APP_PATH;
	public static String PATCH_PATH;
	public static String INMOD_PATH, MOD_PATH;

	public static PiApplicationInfo[] listApps (Context context)
	{
		File appsFile = newFolder(APP_PATH);
		String[] appPackages = appsFile.list();
		int count = appPackages.length;
		PiApplicationInfo[] apps = new PiApplicationInfo[count];
		for (int i = 0; i < count; i ++)
		{
			apps[i] = new PiApplicationInfo(context, appPackages[i]);
		}
		return apps;
	}

	public static PiModuleInfo[] listMods (PackageManager manager)
	{
		List<PiModuleInfo> result = new ArrayList<PiModuleInfo>();
		try
		{
			File[] files = newFolder(PI_PATH + "mod").listFiles();
			for (File file: files)
			{
				try
				{
					PiModuleInfo mod = new PiModuleInfo(file, manager);
					result.add(mod);
				}
				catch (Exception e) {}
			}
		}
		catch (Exception e) {}
		return result.toArray(new PiModuleInfo[result.size()]);
	}

	public static void deleteFile (String path)
	{
		deleteFile(new File(path));
	}

	public static void deleteFile (File file)
	{
		try
		{
			if (file.isFile())
			{
				file.delete();
			}
			else if (file.isDirectory())
			{
				for (File child: file.listFiles())
				{
					deleteFile(child);
				}
				file.delete();
			}
		}
		catch (Exception e) {}
	}

	public static File newFolder (String path)
	{
		File file = new File(path);
		if (file.isFile())
		{
			file.delete();
		}
		file.mkdirs();
		return file;
	}

	public static File newFile (String path)
	{
		File file = new File(path);
		if (file.isDirectory())
		{
			deleteFile(file);
		}
		file.getParentFile().mkdirs();
		return file;
	}

	public static long transfer (InputStream in, OutputStream out) throws Exception
	{
		int len;
		long size = 0;
		byte[] bytes = new byte[8192];
		while ((len = in.read(bytes)) != - 1)
		{
			out.write(bytes, 0, len);
			size += len;
		}
		return size;
	}

	public static String readFile (File file) throws Exception
	{
		InputStream in = new FileInputStream(file);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		transfer(in, out);
		in.close();
		return out.toString("utf-8");
	}

	public static String readFile (String path)
	{
		try
		{
			return readFile(new File(path));
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public static void setZipEntry (ZipEntry entry, ZipEntry newEntry)
	{
		newEntry.setMethod(entry.getMethod());
		if (entry.getMethod() == ZipEntry.STORED)
		{
			newEntry.setCompressedSize(entry.getSize());
			newEntry.setSize(entry.getSize());
			newEntry.setCrc(entry.getCrc());
		}
	}

	public static void initPaths (String dataDir)
	{
		PI_PATH = dataDir + "/files/pinepatch/";
		APP_PATH = PI_PATH + "app/";
		PATCH_PATH = PI_PATH + "patch/";
		INMOD_PATH = PI_PATH + "inmod/";
		MOD_PATH = PI_PATH + "mod/";
	}
}
