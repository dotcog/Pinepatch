package nea.pinepatch;
import java.io.*;
import org.json.*;
import android.content.pm.*;

public class PiModuleInfo
{
	public String packageName, label, description, version;

	public PiModuleInfo (File folder, PackageManager manager) throws Exception
	{
		File manifestFile = Utils.newFile(folder.getPath() + "/manifest.json");
		JSONObject json = new JSONObject(Utils.readFile(manifestFile));
		packageName = json.getString("package");
		label = json.getString("label");
		description = json.getString("description");
		version = json.getString("version");
		try
		{
			ApplicationInfo info = manager.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
			label = info.loadLabel(manager).toString();
			description = info.loadDescription(manager).toString();
		}
		catch (Exception e)
		{
		}
	}

	public void uninstall ()
	{
		Utils.deleteFile(Utils.MOD_PATH + packageName);
	}
}
