package nea.pinepatch;
import android.widget.*;
import android.app.*;
import android.view.*;

public class PiModAdapter extends ArrayAdapter<PiModuleInfo>
{
	public PiModAdapter(Activity activity)
	{
		super(activity, R.layout.item_module);
	}

	@Override
	public View getView(int position, View view, ViewGroup parent)
	{
		Activity activity = (Activity) getContext();
		if (view == null)
		{
			view = activity.getLayoutInflater().inflate(R.layout.item_module, parent, false);
		}
		try
		{
			TextView labelView = view.findViewById(R.id.label);
			TextView packageView = view.findViewById(R.id.package_and_version);
			TextView descriptionView = view.findViewById(R.id.description);
			PiModuleInfo app = getItem(position);
			labelView.setText(app.label);
			packageView.setText(app.version + "  " + app.packageName);
			descriptionView.setText(app.description);
		}
		catch (Exception e)
		{}
		return view;
	}
}
