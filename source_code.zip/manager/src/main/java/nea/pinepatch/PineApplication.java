package nea.pinepatch;
import android.app.*;
import android.content.res.*;

public class PineApplication extends Application
{
	public static AssetManager assets;
	public static PineApplication application;

	public PineApplication ()
	{
		application = this;
	}

	@Override
	public void onCreate()
	{
		super.onCreate();
		Utils.initPaths(getDataDir().getPath());
		assets = getAssets();
	}
}
