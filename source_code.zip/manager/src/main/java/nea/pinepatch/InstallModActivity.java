package nea.pinepatch;
import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import android.net.*;
import java.net.*;
import java.util.zip.*;
import org.json.*;

public class InstallModActivity extends Activity
implements Runnable
{

	Thread thread;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(new ProgressBar(this));
		if (thread == null)
		{
			thread = new Thread(this);
			thread.start();
		}
	}

	@Override
	public void run()
	{
		String errorString = null;
		try
		{
			InputStream in = null;
			Uri uri = getIntent().getData();
			switch (uri.getScheme())
			{
				case "file":
					in = new URL(getIntent().getData().toString()).openStream();
					break;
				case "content":
					in = getContentResolver().openInputStream(uri);
					break;
			}
			String modPath = Utils.INMOD_PATH, packageName = null;
			Utils.deleteFile(modPath);
			ZipInputStream zin = new ZipInputStream(in);
			ZipEntry entry = null;
			while ((entry = zin.getNextEntry()) != null)
			{
				String path = entry.getName();
				if (path.equals("manifest.json"))
				{
					ByteArrayOutputStream bout = new ByteArrayOutputStream();
					Utils.transfer(zin, bout);
					String jsonString = bout.toString("utf-8");
					JSONObject json = new JSONObject(jsonString);
					packageName = json.getString("package");
					FileWriter fout = new FileWriter(Utils.newFile(modPath + path));
					fout.write(json.toString());
					fout.flush();
					fout.close();
				}
				else
				{
					OutputStream fout = new FileOutputStream(Utils.newFile(modPath + path));
					Utils.transfer(zin, fout);
					fout.flush();
					fout.close();
				}
				zin.closeEntry();
			}
			zin.close();
			in.close();
			Utils.deleteFile(Utils.MOD_PATH + packageName);
			Utils.newFolder(modPath).renameTo(Utils.newFolder(Utils.MOD_PATH + packageName));
		}
		catch (Throwable e)
		{
			errorString = e.toString();
		}
		final String finalErrorString = errorString;
		runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					if (finalErrorString == null)
					{
						setTitle(R.string.finish);
						setContentView(R.layout.activity_install_mod);
					} else
					{
						Toast.makeText(InstallModActivity.this, finalErrorString, Toast.LENGTH_SHORT).show();
						finishAndRemoveTask();
					}
				}
			});
	}
}
