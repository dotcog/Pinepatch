package nea.pinepatch;
 
import android.app.*;
import android.os.*;
import android.content.pm.*;
import android.*;
import android.widget.*;
import android.view.*;
import java.io.*;
import android.widget.AdapterView.*;
import android.content.*;

public class MainActivity extends Activity
implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		if (checkStoragePermission())
		{
			create();
		} else
		{
			Toast.makeText(this, R.string.permission_first, Toast.LENGTH_SHORT).show();
			finishAndRemoveTask();
		}
	}

	PiApplicationInfo[] apps = new PiApplicationInfo[0];
	PiAppAdapter adapter;

	public void create ()
	{
		setContentView(R.layout.activity_main);
		adapter = new PiAppAdapter(this);
		ListView list = findViewById(R.id.list);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		list.setOnItemLongClickListener(this);
		list.setId(1);
		reload();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		switch (parent.getId())
		{
			case 1:
				final PiApplicationInfo app = (PiApplicationInfo) parent.getItemAtPosition(position);
				final ProgressDialog loading = newLoadingDialog();
				new Thread() {
					public void run ()
					{
						final PiModuleInfo[] mods = Utils.listMods(getPackageManager());
						String modsString = "\n";
						try
						{
							modsString = Utils.readFile(Utils.newFile(Utils.APP_PATH + app.packageName + "/modules"));
							if (! modsString.startsWith("\n"))
							{
								modsString = "\n" + modsString;
							}
							if (! modsString.endsWith("\n"))
							{
								modsString = modsString + "\n";
							}
						}
						catch (Exception e) {}
						final String finalMods = modsString;
						runOnUiThread(new Runnable() {

								@Override
								public void run()
								{
									loading.cancel();
									MainActivity main = MainActivity.this;
									ListView list = new ListView(main);
									final String[] fmods = new String[] {finalMods};
									try
									{
										final PiModAdapter adapter = new PiModAdapter(main) {
											public View getView(int position, View view, ViewGroup parent)
											{
												view = super.getView(position, view, parent);
												PiModuleInfo mod = getItem(position);
												if (fmods[0].contains("\n" + mod.packageName + "\n"))
												{
													view.setBackgroundColor(0x80808080);
												}
												else
												{
													view.setBackground(null);
												}
												return view;
											}
										};
										list.setAdapter(adapter);
										list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

												@Override
												public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
												{
													PiModuleInfo mod = (PiModuleInfo) parent.getItemAtPosition(position);
													String packageName = mod.packageName;
													String fmod = fmods[0];
													if (fmod.contains("\n" + packageName + "\n"))
													{
														fmod = fmod.replace("\n" + packageName + "\n", "\n");
													}
													else
													{
														fmod = fmod + packageName + "\n";
													}
													try
													{
														FileWriter out = new FileWriter(Utils.newFile(Utils.APP_PATH + app.packageName + "/modules"));
														out.write(fmod);
														out.flush();
														out.close();
													}
													catch (Exception e)
													{}
													fmods[0] = fmod;
													adapter.notifyDataSetChanged();
												}
											});
										adapter.addAll(mods);
									}
									catch (Exception e)
									{}
									new AlertDialog.Builder(main).setTitle(R.string.modules_active_area).setView(list).show();
								}
							});
					}
				}.start();
				break;
			case 2:
				PiModuleInfo mod = (PiModuleInfo) parent.getItemAtPosition(position);
				try
				{
					startActivity(new Intent().setComponent(new ComponentName(mod.packageName, mod.packageName + ".PiActivity")));
				}
				catch (Throwable e) {}
		}
	}

	@Override
	public boolean onItemLongClick(final AdapterView<?> parent, View view, int position, long itemId)
	{
		switch (parent.getId())
		{
			case 1:
				final PiApplicationInfo app = (PiApplicationInfo) parent.getItemAtPosition(position);
				PopupMenu menu = new PopupMenu(this, view);
				Menu raw = menu.getMenu();
				raw.add(R.string.delete).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

						@Override
						public boolean onMenuItemClick(MenuItem item)
						{
							app.uninstall();
							((PiAppAdapter) parent.getAdapter()).remove(app);
							return true;
						}
					});
				raw.add(R.string.set_apk_path).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){

						@Override
						public boolean onMenuItemClick(MenuItem item)
						{
							MainActivity main = MainActivity.this;
							LinearLayout view = new LinearLayout(main);
							final EditText edit = new EditText(main);
							LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(- 1, - 1);
							int margin = (int) (getResources().getDisplayMetrics().density * 24);
							layout.setMargins(margin, 0, margin, 0);
							edit.setLayoutParams(layout);
							view.addView(edit);
							final File file = Utils.newFile(Utils.APP_PATH + app.packageName + "/apkpath");
							try
							{
								edit.setText(Utils.readFile(file));
							}
							catch (Exception e)
							{}
							new AlertDialog.Builder(main).setTitle(R.string.set_apk_path).setView(view).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										try
										{
											FileWriter out = new FileWriter(file);
											out.write(edit.getText().toString());
											out.flush();
											out.close();
										}
										catch (Exception e) {}
									}
								}).setNegativeButton(android.R.string.cancel, null).show();
							return true;
						}
					});
				raw.add(R.string.set_so_path).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){

						@Override
						public boolean onMenuItemClick(MenuItem item)
						{
							MainActivity main = MainActivity.this;
							LinearLayout view = new LinearLayout(main);
							final EditText edit = new EditText(main);
							LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(- 1, - 1);
							int margin = (int) (getResources().getDisplayMetrics().density * 24);
							layout.setMargins(margin, 0, margin, 0);
							edit.setLayoutParams(layout);
							view.addView(edit);
							final File file = Utils.newFile(Utils.APP_PATH + app.packageName + "/sopath");
							try
							{
								edit.setText(Utils.readFile(file));
							}
							catch (Exception e)
							{}
							new AlertDialog.Builder(main).setTitle(R.string.set_so_path).setView(view).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										try
										{
											FileWriter out = new FileWriter(file);
											out.write(edit.getText().toString());
											out.flush();
											out.close();
										}
										catch (Exception e) {}
									}
								}).setNegativeButton(android.R.string.cancel, null).show();
							return true;
						}
					});
				menu.show();
				break;
			case 2:
				PiModuleInfo mod = (PiModuleInfo) parent.getItemAtPosition(position);
				mod.uninstall();
				((PiModAdapter) parent.getAdapter()).remove(mod);
				break;
		}
		return true;
	}

	public void reload ()
	{
		final ProgressDialog loadingDialog = newLoadingDialog();
		new Thread()
		{
			public void run()
			{
				final PiApplicationInfo[] apps = Utils.listApps(MainActivity.this);
				runOnUiThread(new Runnable() {

						@Override
						public void run()
						{
							MainActivity.this.apps = apps;
							loadingDialog.cancel();
							adapter.clear();
							adapter.addAll(apps);
							adapter.notifyDataSetInvalidated();
						}
					});
			}
		}.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.layout.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.reload:
				reload();
				break;
			case R.id.manage_module:
				final ProgressDialog loading = newLoadingDialog();
				new Thread()
				{
					public void run ()
					{
						final PiModuleInfo[] mods = Utils.listMods(getPackageManager());
						runOnUiThread(new Runnable() {

								@Override
								public void run()
								{
									loading.cancel();
									MainActivity main = MainActivity.this;
									ListView list = new ListView(main);
									list.setId(2);
									PiModAdapter adapter = new PiModAdapter(main);
									list.setAdapter(adapter);
									list.setOnItemLongClickListener(main);
									list.setOnItemClickListener(main);
									adapter.addAll(mods);
									new AlertDialog.Builder(main).setTitle(R.string.manage_module).setView(list).show();
								}
							});
					}
				}.start();
				break;
		}
		return true;
	}

	public ProgressDialog newLoadingDialog()
	{
		ProgressDialog loadingDialog = new ProgressDialog(this);
		loadingDialog.setCancelable(false);
		loadingDialog.setMessage(getString(R.string.loading));
		loadingDialog.show();
		return loadingDialog;
	}

	private boolean checkStoragePermission()
	{
		int permission = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
		return permission == PackageManager.PERMISSION_GRANTED;
	}
}
