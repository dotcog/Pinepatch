package nea.pinepatch;

import android.content.*;
import android.database.*;
import android.net.*;
import android.content.res.*;
import java.io.*;
import android.os.*;

public class PineProvider extends ContentProvider
{

	@Override
	public boolean onCreate()
	{
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] p2, String p3, String[] p4, String p5)
	{
		try
		{
			String path = uri.getPath().substring(1);
			if (path.startsWith("proxy/"))
			{
				return PineApplication.application.getContentResolver().query(Uri.parse("content://" + path.substring(6)), null, null, null, null);
			}
			String[] words = path.split("/");
			String first = words[0];
			if (first.equals("config"))
			{
				String arch = words[1], packageName = words[2];
				MatrixCursor cursor = new MatrixCursor(new String[] {"apk_path", "lib_path", "apk_size", "lib_size", "raw_appcf", "modules"});
				String filePath = Utils.APP_PATH + packageName;
				String apkPath = null, libPath = null, rawAppcf = null, modules = null;
				long apkSize = 0, libSize = 0;
				apkPath = Utils.readFile(filePath + "/apkpath");
				libPath = Utils.readFile(filePath + "/sopath");
				rawAppcf = Utils.readFile(filePath + "/rawappcf");
				modules = Utils.readFile(filePath + "/modules");
				if (modules == null) modules = "";
				apkSize = new File(filePath + "/rawapk").length();
				AssetManager assets = PineApplication.assets;
				InputStream in = assets.open("arm" + arch + ".so");
				libSize = in.available();
				in.close();
				cursor.addRow(new Object[] {apkPath, libPath, apkSize, libSize, rawAppcf, modules});
				return cursor;
			} else if (first.equals("sign"))
			{
				String packageName = words[1];
				File signFile = new File(Utils.APP_PATH + packageName + "/rawsign");
				String sign = null;
				if (signFile.exists())
				{
					sign = Utils.readFile(signFile);
				} else
				{
					return null;
				}
				MatrixCursor cursor = new MatrixCursor(new String[] {"sign"});
				cursor.addRow(new Object[] {sign});
				return cursor;
			} else if (first.equals("module_dexs"))
			{
				String packageName = words[1];
				String dexPath = Utils.MOD_PATH + packageName;
				File dexFile = new File(dexPath);
				MatrixCursor cursor = new MatrixCursor(new String[] {"path"});
				for (String dexItem: dexFile.list())
				{
					if (dexItem.endsWith("dex") && new File(dexFile, dexItem).isFile())
					{
						cursor.addRow(new Object[] {dexItem});
					}
				}
				return cursor;
			}
		}
		catch (Throwable e)
		{
		}
		return null;
	}

	@Override
	public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException
	{
		String path = uri.getPath().substring(1);


		String[] words = path.split("/");
		String first = words[0];
		switch (first)
		{
			case "apk":
				String apkPath = Utils.APP_PATH + words[1] + "/rawapk";
				return ParcelFileDescriptor.open(new File(apkPath), ParcelFileDescriptor.MODE_READ_ONLY);
			case "module_dex":
				return ParcelFileDescriptor.open(new File(Utils.MOD_PATH + words[1] + "/" + words[2]), ParcelFileDescriptor.MODE_READ_ONLY);
			case "lib":
				String arch = words[1];
				try
				{
					String fileName = "arm" + arch + ".so";
					String soPath = Utils.PI_PATH + fileName;
					File soFile = Utils.newFile(soPath);
					if (! soFile.exists())
					{
						InputStream in = PineApplication.assets.open(fileName);
						OutputStream out = new FileOutputStream(soPath);
						Utils.transfer(in, out);
						in.close();
						out.flush();
						out.close();
					}
					return ParcelFileDescriptor.open(soFile, ParcelFileDescriptor.MODE_READ_ONLY);
				}
				catch (Exception e)
				{
					break;
				}
		}
		return null;
	}

	@Override
	public String getType(Uri p1)
	{
		return null;
	}

	@Override
	public Uri insert(Uri p1, ContentValues p2)
	{
		return null;
	}

	@Override
	public int delete(Uri p1, String p2, String[] p3)
	{
		return 0;
	}

	@Override
	public int update(Uri p1, ContentValues p2, String p3, String[] p4)
	{
		return 0;
	}
}

