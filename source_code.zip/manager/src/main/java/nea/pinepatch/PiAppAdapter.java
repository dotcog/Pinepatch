package nea.pinepatch;
import android.widget.*;
import android.app.*;
import android.view.*;
import android.graphics.drawable.*;

public class PiAppAdapter extends ArrayAdapter<PiApplicationInfo>
{
	public PiAppAdapter(Activity activity)
	{
		super(activity, R.layout.item_application);
	}

	@Override
	public View getView(int position, View view, ViewGroup parent)
	{
		Activity activity = (Activity) getContext();
		if (view == null)
		{
			view = activity.getLayoutInflater().inflate(R.layout.item_application, parent, false);
		}
		try
		{
			TextView labelView = view.findViewById(R.id.label);
			View iconView = view.findViewById(R.id.icon);
			PiApplicationInfo app = getItem(position);
			if (app.isInstalled)
			{
				labelView.setText(app.label);
				iconView.setBackground(app.icon);
			} else
			{
				labelView.setText(activity.getString(R.string.not_installed, app.packageName));
				iconView.setBackgroundDrawable(null);
			}
		}
		catch (Exception e)
		{}
		return view;
	}
}
