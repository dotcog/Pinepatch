package com.apk.axml.utils;

public interface ReferenceResolver {

    int resolve(ValueChunk value, String ref);

}
