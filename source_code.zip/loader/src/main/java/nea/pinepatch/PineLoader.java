package nea.pinepatch;
import android.app.*;

import android.app.*;
import android.content.pm.*;
import dalvik.system.*;
import java.io.*;
import android.os.*;
import android.content.*;
import java.nio.*;
import java.lang.reflect.*;
import java.util.*;
import top.canyie.pine.*;
import java.nio.file.attribute.*;
import android.system.*;
import java.nio.file.*;
import android.database.*;
import android.net.*;

public class PineLoader extends AppComponentFactory
{

	public static String libPath;

	static
	{
		try
		{
			ClassLoader cl = PineLoader.class.getClassLoader();
			Class<?> VMRuntime = Class.forName("dalvik.system.VMRuntime");
            Method getRuntime = VMRuntime.getDeclaredMethod("getRuntime");
            getRuntime.setAccessible(true);
			Object runtime = getRuntime.invoke(null);
            Method vmInstructionSet = VMRuntime.getDeclaredMethod("vmInstructionSet");
            vmInstructionSet.setAccessible(true);
            String arch = (String) vmInstructionSet.invoke(runtime);
			if ("arm64".equals(arch))
			{
				arch = "64";
			} else
			{
				arch = "32";
			}
			Class<?> activityThreadClass = cl.loadClass("android.app.ActivityThread"), loadedApkClass = cl.loadClass("android.app.LoadedApk");
			Object thread = activityThreadClass.getMethod("currentActivityThread").invoke(null);
			Object bound = getField(thread, "mBoundApplication");
			Object stubLoadedApk = getField(bound, "info");
			ApplicationInfo appInfo = (ApplicationInfo) getField(bound, "appInfo");
			String packageName = appInfo.packageName;
			Method createAppContext = Class.forName("android.app.ContextImpl").getDeclaredMethod("createAppContext", activityThreadClass, loadedApkClass);
			createAppContext.setAccessible(true);
			appInfo.appComponentFactory = null;
			Context stubContext = (Context) createAppContext.invoke(null, thread, stubLoadedApk);
			ContentResolver content = stubContext.getContentResolver();
			Cursor cursor = content.query(Uri.parse("content://nea.pinepatch/config/" + arch + "/" + packageName), null, null, null, null);
			cursor.moveToFirst();
			String apkPath = appInfo.dataDir + "/" + cursor.getString(0);
			appInfo.sourceDir = appInfo.publicSourceDir = apkPath;
			libPath = appInfo.dataDir + "/" + cursor.getString(1);
			long apkSize = cursor.getLong(2);
			long libSize = cursor.getLong(3);
			String applicationName = cursor.getString(4);
			if (applicationName != null)
			{
				if (applicationName.startsWith("."))
				{
					applicationName = packageName + applicationName;
				}
			}
			appInfo.appComponentFactory = applicationName;
			String[] modules = cursor.getString(5).split("\n");
			cursor.close();
			boolean shouldCopy = false;
			File apkFile = newFile(apkPath);
			if (apkFile.exists())
			{
				shouldCopy = apkFile.length() != apkSize;
			} else
			{
				shouldCopy = true;
			}
			if (shouldCopy)
			{
				InputStream apkIn = content.openInputStream(Uri.parse("content://nea.pinepatch/apk/" + packageName));
				OutputStream apkOut = new FileOutputStream(apkPath);
				transfer(apkIn, apkOut);
				apkIn.close();
				apkOut.flush();
				apkOut.close();
			}
			File libFile = newFile(libPath);
			if (libFile.exists())
			{
				shouldCopy = libFile.length() != libSize;
			} else
			{
				shouldCopy = true;
			}
			if (shouldCopy)
			{
				InputStream apkIn = content.openInputStream(Uri.parse("content://nea.pinepatch/lib/" + arch));
				OutputStream apkOut = new FileOutputStream(libPath);
				transfer(apkIn, apkOut);
				apkIn.close();
				apkOut.flush();
				apkOut.close();
			}
			Map<?, ?> packages = (Map<?, ?>) getField(thread, "mPackages");
			packages.clear();
			Object compat = null;
			try
			{
				compat = getField(bound, "compatInfo");
			}
			catch (Exception e)
			{
			}
			Method method = activityThreadClass.getDeclaredMethod("getPackageInfoNoCheck", ApplicationInfo.class, cl.loadClass("android.content.res.CompatibilityInfo"));
			method.setAccessible(true);
			Object appLoadedApk = method.invoke(thread, appInfo, compat);
			setField(bound, "info", appLoadedApk);
			Class<?> activityClientRecordClass = activityThreadClass.getClassLoader().loadClass("android.app.ActivityThread$ActivityClientRecord");
			Map<?, ?> activities = (Map<?, ?>) getField(thread, "mActivities");
			for (Object v: activities.values())
			{
				if (activityClientRecordClass.isInstance(v))
				{
					Object pkgInfo = getField(v, "packageInfo");
					if (pkgInfo == stubLoadedApk)
					{
						setField(v, "packageInfo", appLoadedApk);
					}
				}
			}
			try
			{
				Map<?, ?> launchingActivities = (Map<?, ?>) getField(thread, "mLaunchingActivities");
				for (Object v: launchingActivities.values())
				{
					if (activityClientRecordClass.isInstance(v))
					{
						Object pkgInfo = getField(v, "packageInfo");
						if (pkgInfo == stubLoadedApk)
						{
							setField(v, "packageInfo", appLoadedApk);
						}
					}
				}
			}
			catch (Throwable e)
			{}
			method = Class.forName("android.app.ContextImpl").getDeclaredMethod("createAppContext", activityThreadClass, loadedApkClass);
			method.setAccessible(true);
			Context context = (Context) method.invoke(null, thread, appLoadedApk);
			method = Pine.findMethod(loadedApkClass, "getClassLoader");
			method.setAccessible(true);
			ClassLoader appClassLoader = (ClassLoader) method.invoke(appLoadedApk);
			try
			{
				for (String module: modules)
				{
					if (module.length() == 0) continue;
					try
					{
						InputStream moduleIn = content.openInputStream(Uri.parse("content://nea.pinepatch/module/" + module));
						ByteBuffer buffer = ByteBuffer.allocate(moduleIn.available());
						int len;
						byte[] bytes = new byte[8192];
						while ((len = moduleIn.read(bytes)) != - 1)
						{
							buffer.put(bytes, 0, len);
						}
						buffer.position(0);
						moduleIn.close();
						InMemoryDexClassLoader moduleClassLoader = new InMemoryDexClassLoader(new ByteBuffer[]{buffer}, appInfo.nativeLibraryDir, cl);
						Class<?> hookClass = moduleClassLoader.loadClass("MainHook");
						try
						{
							hookClass.getDeclaredMethod("hook", ClassLoader.class, ApplicationInfo.class, Context.class).invoke(null, appClassLoader, appInfo, context);
						}
						catch (Throwable e)
						{}
						try
						{
							hookClass.getDeclaredMethod("hook", ClassLoader.class, ApplicationInfo.class, String.class, String.class).invoke(null, appClassLoader, appInfo, packageName, appInfo.dataDir + "/pipatch_mods/" + module);
						}
						catch (Throwable e)
						{}
					}
					catch (Throwable e)
					{
						/*StringWriter out = new StringWriter();
						 e.printStackTrace(new PrintWriter(out));
						 startActivity(new Intent().setClassName("nea.myapp", "nea.myapp.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT).putExtra("error", out.toString()));*/
					}
				}
			}
			catch (Throwable e)
			{
			}
			for (Field field: loadedApkClass.getDeclaredFields())
			{
				if (field.getType() == ClassLoader.class)
				{
					field.setAccessible(true);
					ClassLoader mClassLoader = (ClassLoader) field.get(appLoadedApk);
					field.set(stubLoadedApk, mClassLoader);
				}
			}
		}
		catch (Throwable e)
		{
			/*try
			{
				FileWriter out = new FileWriter("/sdcard/pipatch/error.log");
				e.printStackTrace(new PrintWriter(out));
				out.flush();
				out.close();
			}
			catch (Exception e2)
			{}*/
		}
	}

	public static void deleteFile(String path)
	{
		deleteFile(new File(path));
	}

	public static void deleteFile(File file)
	{
		try
		{
			if (file.isFile())
			{
				file.delete();
			} else if (file.isDirectory())
			{
				for (File child: file.listFiles())
				{
					deleteFile(child);
				}
				file.delete();
			}
		}
		catch (Exception e)
		{}
	}

	public static String readFile(String path) throws IOException
	{
		FileInputStream in = new FileInputStream(path);
		byte[] bytes = new byte[in.available()];
		in.read(bytes);
		in.close();
		return new String(bytes, "utf-8");
	}

	public static File newFile(String path)
	{
		File file = new File(path);
		if (file.isDirectory())
		{
			deleteFile(file);
		}
		file.getParentFile().mkdirs();
		return file;
	}

	public static long transfer(InputStream in, OutputStream out) throws Exception
	{
		int len;
		long size = 0;
		byte[] bytes = new byte[1024];
		while ((len = in.read(bytes)) != - 1)
		{
			out.write(bytes, 0, len);
			size += len;
		}
		return size;
	}

	public static Object getField(Object thisObject, String fieldName) throws Exception
	{
		Field field = Pine.findField(thisObject.getClass(), fieldName);
		field.setAccessible(true);
		return field.get(thisObject);
	}

	public static void setField(Object thisObject, String fieldName, Object fieldValue) throws Exception
	{
		Field field = Pine.findField(thisObject.getClass(), fieldName);
		field.setAccessible(true);
		field.set(thisObject, fieldValue);
	}
}

